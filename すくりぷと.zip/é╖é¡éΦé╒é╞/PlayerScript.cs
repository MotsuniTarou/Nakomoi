﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerScript : MonoBehaviour
{
    [Header("移動速度")] public float speed;
    public GameObject fire;
    private bool Dash = false;
    private bool Masic1 = false;
    private bool Masic2 = false;
    private bool Masic3 = false;
    private Vector3 Player_pos;     //プレイヤーのポジション
    private float x, xs = 0;                //x方向にインプットする値
    private float z, zs = 0;                //z方向にインプットする値
    private Rigidbody rb = null;
    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody>();
        Player_pos = GetComponent<Transform>().position;
    }

    // Update is called once per frame
    void Update()
    {

        x = Input.GetAxis("Horizontal");
        z = Input.GetAxis("Vertical");

        if (Input.GetKeyDown("h"))
        {//炎魔法
            Instantiate(fire, transform.position, transform.rotation);
        }

        if (Input.GetKeyDown("g"))
        {//ダッシュはじめ
            speed = speed * 2;
        }
        else if (Input.GetKeyUp("g"))
        {
            speed = speed / 2;
        }

        Vector3 diff = transform.position - Player_pos;
        if (!((diff.x > 0.0001 || diff.x < -0.0001) && (diff.z > 0.0001 || diff.z < -0.001)))  //斜め移動時に角度が変わらないようにする
        {

            if (diff.magnitude > 0.001f)
            {
                transform.rotation = Quaternion.LookRotation(diff);
            }

            if (x > 0) xs = 1;
            else if (x < 0) xs = -1;
            else xs = 0;

            if (z > 0) zs = 1;
            else if (z < 0) zs = -1;
            else zs = 0;
        }
        else
        {
            Debug.Log(transform.position.x + "Xtp");
            Debug.Log(transform.position.z + "Ztp");
            Debug.Log(Player_pos.x + "Xps");
            Debug.Log(Player_pos.x + "Zps");
            Debug.Log(diff.x + "Xdiff");
            Debug.Log(diff.z + "Zdiff");
        }

        rb.velocity = new Vector3(xs * speed, 0, zs * speed);
        Player_pos = transform.position;
        
    }
}
