﻿using System.Collections;
using System.Collections.Generic;
using System.Security.Cryptography;
using UnityEngine;

public class FireScript : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        transform.Translate(0, 0, 0.2f);
        if (transform.position.x > 5|| transform.position.x < -5 || transform.position.z > 5 || transform.position.z < -5 )
        {
            Destroy(gameObject);
        }
    }
}
